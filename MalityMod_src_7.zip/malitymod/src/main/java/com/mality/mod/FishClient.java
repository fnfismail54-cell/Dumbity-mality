package com.mality.mod;

import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fish Audio TTS: metni WAV sese çevirir (POST /v1/tts). */
public final class FishClient {
    private static final Pattern HEX32 = Pattern.compile("[0-9a-fA-F]{32}");

    private static final class HttpFail extends Exception {
        final int code;

        HttpFail(int code, String msg) {
            super(msg);
            this.code = code;
        }
    }

    private FishClient() {}

    public static String cleanKey(String k) {
        if (k == null) return "";
        String s = k.trim().replace("\"", "");
        if (s.regionMatches(true, 0, "Bearer ", 0, 7)) s = s.substring(7);
        return s.trim();
    }

    /** Ses model ID'si: link yapıştırdıysan içinden 32 haneli ID'yi çıkarır. */
    public static String cleanVoiceId(String v) {
        if (v == null) return "";
        String s = v.trim();
        Matcher m = HEX32.matcher(s);
        if (m.find()) return m.group();
        return s;
    }

    public static CompletableFuture<byte[]> tts(String apiKey, String voiceId, String engine, String text) {
        return CompletableFuture.supplyAsync(() -> {
            Set<String> engines = new LinkedHashSet<>();
            // Ücretsiz model en başta; eski varsayılanlar (s1 / s2-pro) kredi isteyebilir, o yüzden yedek
            String cfg = engine == null ? "" : engine.trim();
            engines.add("s2.1-pro-free");
            if (!cfg.isEmpty() && !cfg.equals("s1") && !cfg.equals("s2-pro")) engines.add(cfg);
            engines.add("s2-pro");
            engines.add("s1");
            String lastMsg = "Fish Audio cevap vermedi";
            for (String eng : engines) {
                try {
                    return once(apiKey, cleanVoiceId(voiceId), eng, text);
                } catch (HttpFail f) {
                    lastMsg = f.getMessage();
                    // anahtar/bakiye/limit/sunucu hatasında başka motor denemenin anlamı yok
                    // 402 (kredi yok) başka motorla geçebilir; devam et
                    if (f.code == 401 || f.code == 403 || f.code == 429 || f.code >= 500) {
                        throw new RuntimeException(lastMsg);
                    }
                } catch (IOException io) {
                    throw new RuntimeException(io.getClass().getSimpleName() + ": " + io.getMessage());
                }
            }
            throw new RuntimeException(lastMsg);
        });
    }

    private static byte[] once(String apiKey, String voiceId, String engine, String text) throws IOException, HttpFail {
        JsonObject body = new JsonObject();
        body.addProperty("text", text);
        if (!voiceId.isBlank()) body.addProperty("reference_id", voiceId);
        body.addProperty("format", "wav");
        body.addProperty("sample_rate", 24000);
        body.addProperty("normalize", true);

        HttpURLConnection c = (HttpURLConnection) new URL("https://api.fish.audio/v1/tts").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(10_000);
        c.setReadTimeout(30_000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + apiKey);
        c.setRequestProperty("model", engine);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = code / 100 == 2 ? c.getInputStream() : c.getErrorStream();
        byte[] data = is == null ? new byte[0] : is.readAllBytes();
        if (code / 100 != 2) {
            String msg = new String(data, StandardCharsets.UTF_8);
            if (msg.length() > 180) msg = msg.substring(0, 180);
            throw new HttpFail(code, "Fish Audio HTTP " + code + " (motor " + engine + "): " + msg);
        }
        if (data.length < 44 || data[0] != 'R' || data[1] != 'I' || data[2] != 'F' || data[3] != 'F') {
            String msg = new String(data, 0, Math.min(data.length, 140), StandardCharsets.UTF_8);
            throw new HttpFail(400, "Fish Audio WAV göndermedi (motor " + engine + "): " + msg);
        }
        return data;
    }
}
