package com.mality.mod;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MalityEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> BORED = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> TALKING = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SLEEPING = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SCARED = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> FALLING = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> ROLLING = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> COOKING = SynchedEntityData.defineId(MalityEntity.class, EntityDataSerializers.BOOLEAN);

    public static final String PET_TAG = "malitymod_pet";

    // ------------------------------------------------------------------ söz havuzları (hep aynı şeyi demesin)
    private static final String[] DUMB = {
            "Daha geçen bir inekle uçtum!", "Toprak yemek çok güzel, sen de bir ısır!",
            "Dün bir koyunla yarışa girdim, ben kazandım galiba.", "Ağaçlar bana bakıyor, sanırım beni seviyorlar.",
            "Ben bir kez bir domuza matematik öğrettim.", "Bir çukur kazdım, sonra içine düştüm, çok ilginçti.",
            "Bulutlar çok yakın bugün, dokunsam mı?", "Dün gece rüyamda yumurta oldum.",
            "Bunu tabii ki biliyorum ama sana söylemeyeceğim, hihi.", "Ben yuvarlak olduğum için hiç köşeye sıkışmam.",
            "Bir keresinde bir tavuğa şarkı söyledim, çok alkışladı.", "Sence ben kaç kilo gelirim?",
            "Bugün kendime bir isim buldum: Mality.", "Güneş sürekli beni takip ediyor, fark ettin mi?",
            "Toprağın tadı bazen mavi, bazen biraz daha mavi.", "Kimse bana ayakkabı almıyor ama ayağım da yok."
    };
    private static final String[] BOX_LINES = {
            "Kutu çok dardı, içeride bir solucanla anlaşamadık.", "Selam! Ben kutudan çıktım, ya sen?",
            "Burası neresi? Yemek var mı?", "Uçuyordum, sonra düştüm, sonra tıp dedi!",
            "Kutunun içi karanlıktı, hiç korkmadım. Biraz korktum.", "Merhaba dünya! Merhaba toprak!"
    };
    private static final String[] HOUSE_GREET = {
            "Ev çok kötü oldu, köpeğe söylemeyin de üzülmesin.", "Evi çatıdan başlayarak yaptım, bence bir yenilik.",
            "Duvarlar eğri ama sanat bu, sanat!", "Kapıyı unuttum galiba ama pencere de işe yarar.",
            "Güzel oldu mu? Bence harika oldu, kimseye sorma.", "Bu ev depreme dayanıklı, çünkü zaten yıkık."
    };
    private static final String[] ADD_LINES = {
            "Şimdi %s ekliyorum.", "Bir tutam da %s atalım!", "Sırada %s var!", "Bunun içine %s lazım, kesin.",
            "%s koymazsam olmaz."
    };
    private static final String[] PRAISE = {
            "Harika bir yemek oldu!", "Bu şimdiye kadarki en güzel yemeğim!",
            "Mükemmel! Kokusu bile süper.", "Yemek bitti, afiyet olsun!"
    };
    private static final String[] COOK_START = {
            "Aşçı şapkamı takıyorum, yemek vakti!", "Tamam, hemen mutfağı kuruyorum!", "Şef Mality göreve hazır!"
    };
    private static final String[] WAKE = {
            "Hm? Ne? Ben uyumuyordum...", "Zzz... ha, günaydın!", "Rüyamda yemek yiyordum, bozdun!"
    };
    private static final String[] IGNORE = {
            "Bir zombi var ama ben görmedim. Görmedim.", "Hmm, yeşil bir şey, neyse.", "Ben şimdi başka işle meşgulüm."
    };
    private static final String[] SHEEP_LINES = {"Hey merhaba koyuncuk!", "Koyuncuk, sen bulut musun?", "Koyuncuk, yünün çok yumuşak görünüyor."};
    private static final String[] PIG_LINES = {"Hey merhaba domuzcuk!", "Domuzcuk, sen de toprak seviyor musun?", "Domuzcuk bana bir elma getirir misin?"};
    private static final String[] COW_LINES = {"Hey inekçik, hatırlıyor musun seninle uçmuştuk?", "İnekçik, süt mü ayran mı?", "Merhaba inekçik!"};
    private static final String[] CHICKEN_LINES = {"Hey tavukçuk, yumurtaların altın mı?", "Merhaba tavukçuk, kanat çırpma yarışı yapalım mı?"};

    // ---- alt sınıfların (Dumbity) değiştirebildiği ayarlar
    protected String displayName() { return "Mality"; }
    protected String chatColor() { return "\u00A7d"; }
    protected String persona() { return GroqClient.SYSTEM; }
    protected String voiceModel() { return Config.FISH_MODEL.get(); }
    protected String[] dumbLines() { return DUMB; }
    /** Dumbity true döner: nazik/akıllı davranır, Mality'nin saçma işlerini yapmaz, güzel tezgahta iyi yemek yapar. */
    protected boolean isSmart() { return false; }
    protected String[] addLines() { return ADD_LINES; }
    protected String[] praiseLines() { return PRAISE; }

    private enum Mode { IDLE, FOLLOW, STAY }

    private record Ingredient(String name, Item item, boolean poison) {}

    private Mode mode = Mode.IDLE;
    private UUID followId;
    private UUID adoptId;
    private UUID rollTargetId;
    private UUID petId;
    private UUID cookOwner;
    private BlockPos stayPos;
    private BlockPos bedPos;
    private BlockPos counterPos;
    private Vec3 moveTarget;
    private double moveSpeed = 1.0D;
    private Vec3 fleeFrom;
    private Vec3 petPos;

    private int sleepState; // 0 uyanık, 1 yatağa gidiyor, 2 uyuyor
    private boolean sleepNight;
    private int sleepWakeAt;
    private int bedTimer;

    private int talkTicks;
    private int eatTicks;
    private int helpTicks;
    private int attackTicks;
    private int fleeTicks;
    private int scaredTicks;
    private int zombieCd;
    private int animalCd = 20 * 20;
    private int pendingLines;
    private int lineTimer;
    private int lastInteraction;
    private int chatterCooldown = 20 * 30;
    private int blockCooldown;
    private boolean thinking;
    private boolean voiceBusy;
    private boolean warnedNoKey;
    private String pendingRaw;
    private UUID pendingPlayer;
    private int thinkingSince;
    private String queuedVoice;
    private String lastErr = "";
    private int lastErrTick = -100000;
    private boolean fallingFlag;
    private int fallingTicks;

    private boolean cooking;
    private int cookStep;
    private int cookTimer;
    private boolean cookPoison;
    private final List<Ingredient> cookIngr = new ArrayList<>();

    private AABB houseBox;
    private boolean houseGreeted = true;
    private boolean houseNice;
    private static final String[] NICE_GREET = {
            "Güzel oldu mu? Köpek bayılacak!", "İçerisi de dışarısı da pırıl pırıl, değil mi?",
            "İki katlı, camlı, kuvars. Bence çok şık.", "Üst katta pembe bir yatak da var, bak!"
    };

    private final List<JsonObject> history = new ArrayList<>();

    // Mality <-> Dumbity sohbeti
    private String peerText;
    private String peerFromName;
    private int peerDelay;
    private int peerChain;
    private int lastPeerTick = -100000;

    // istemci tarafı yuvarlanma animasyonu
    public float rollPhase;
    public float rollPhaseO;

    public MalityEntity(EntityType<? extends MalityEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(BORED, false);
        this.entityData.define(TALKING, false);
        this.entityData.define(SLEEPING, false);
        this.entityData.define(SCARED, false);
        this.entityData.define(FALLING, false);
        this.entityData.define(ROLLING, false);
        this.entityData.define(COOKING, false);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    public boolean isBored() { return this.entityData.get(BORED); }
    public boolean isTalking() { return this.entityData.get(TALKING); }
    public boolean isSleepingBall() { return this.entityData.get(SLEEPING); }
    public boolean isScared() { return this.entityData.get(SCARED); }
    public boolean isFallingOut() { return this.entityData.get(FALLING); }
    public boolean isRolling() { return this.entityData.get(ROLLING); }
    public boolean isCooking() { return this.entityData.get(COOKING); }

    private void setBored(boolean b) { this.entityData.set(BORED, b); }

    /** Yüz atlası hücresi: 0 mutlu, 1 mutlu konuşan, 2 sıkılmış, 3 sıkılmış konuşan, 4 uyuyan, 5 korkmuş, 6 düşen */
    public int faceIndex() {
        if (isFallingOut()) return 6;
        if (isSleepingBall()) return 4;
        if (isScared()) return 5;
        boolean t = isTalking();
        if (isBored()) return t ? 3 : 2;
        return t ? 1 : 0;
    }

    public void setFalling(boolean b) {
        this.fallingFlag = b;
        this.fallingTicks = 0;
        this.entityData.set(FALLING, b);
    }

    public void setBed(BlockPos pos) {
        this.bedPos = pos.immutable();
    }

    private boolean busy() {
        return cooking || sleepState != 0 || fleeTicks > 0 || adoptId != null || rollTargetId != null || attackTicks > 0;
    }

    private boolean isNight() {
        long t = this.level().getDayTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    // ------------------------------------------------------------------ goals
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new FreezeGoal(this));
        this.goalSelector.addGoal(1, new MalityMoveGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D) {
            @Override
            public boolean canUse() {
                return mode == Mode.IDLE && moveTarget == null && !busy() && getTarget() == null && super.canUse();
            }
        });
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    /** Yemek yaparken / uyurken olduğu yerde durur. */
    private static class FreezeGoal extends Goal {
        private final MalityEntity m;

        FreezeGoal(MalityEntity m) {
            this.m = m;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return m.cooking || m.sleepState == 2;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            m.getNavigation().stop();
        }
    }

    private static class MalityMoveGoal extends Goal {
        private final MalityEntity m;

        MalityMoveGoal(MalityEntity m) {
            this.m = m;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return m.getTarget() == null && (m.moveTarget != null || m.mode != Mode.IDLE);
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            if (!(m.level() instanceof ServerLevel sl)) return;
            if (m.moveTarget != null) {
                if (m.tickCount % 8 == 0) {
                    m.getNavigation().moveTo(m.moveTarget.x, m.moveTarget.y, m.moveTarget.z, m.moveSpeed);
                }
                return;
            }
            if (m.mode == Mode.FOLLOW && m.followId != null) {
                Player p = sl.getPlayerByUUID(m.followId);
                if (p == null) return;
                m.getLookControl().setLookAt(p);
                if (m.distanceToSqr(p) > 9.0D) {
                    if (m.tickCount % 10 == 0) m.getNavigation().moveTo(p, 1.15D);
                } else {
                    m.getNavigation().stop();
                }
            } else if (m.mode == Mode.STAY && m.stayPos != null) {
                if (m.blockPosition().distSqr(m.stayPos) > 16 && m.tickCount % 20 == 0) {
                    m.getNavigation().moveTo(m.stayPos.getX() + 0.5, m.stayPos.getY(), m.stayPos.getZ() + 0.5, 1.0D);
                }
            }
        }
    }

    // ------------------------------------------------------------------ konuşma + ses
    private static String pick(String[] a) {
        return a[randomIdx(a.length)];
    }

    private static int randomIdx(int n) {
        return (int) (Math.random() * n);
    }

    public void say(String text) {
        if (this.level().isClientSide) return;
        Component msg = Component.literal(chatColor() + "[" + displayName() + "] \u00A7f" + text);
        AABB box = this.getBoundingBox().inflate(Config.CHAT_RANGE.get());
        for (Player p : this.level().getEntitiesOfClass(Player.class, box)) p.sendSystemMessage(msg);
        this.talkTicks = Math.max(30, text.length() * 2);
        this.entityData.set(TALKING, true);
        speakVoice(text);
        notifyPeers(text);
    }

    /** Yakındaki diğer Mality/Dumbity söylediğimi duyar. */
    private void notifyPeers(String text) {
        for (MalityEntity o : this.level().getEntitiesOfClass(MalityEntity.class,
                this.getBoundingBox().inflate(24.0D), e -> e != this && e.isAlive())) {
            o.hearPeer(this, text);
        }
    }

    private void hearPeer(MalityEntity from, String text) {
        if (this.level().isClientSide || sleepState != 0 || cooking) return;
        if (this.tickCount - lastPeerTick > 20 * 60) peerChain = 0;
        if (peerChain >= 3 || peerText != null) return;
        if (GroqClient.cleanKey(Config.GROQ_API_KEY.get()).isEmpty()) return;
        if (this.level().getNearestPlayer(this, 40.0D) == null) return;
        peerText = text;
        peerFromName = from.displayName();
        peerDelay = 40 + text.length() * 2 + randomIdx(30);
    }

    private void askPeer(String fromName, String text) {
        String key = GroqClient.cleanKey(Config.GROQ_API_KEY.get());
        MinecraftServer server = this.getServer();
        if (key.isEmpty() || server == null) return;
        thinking = true;
        thinkingSince = this.tickCount;
        peerChain++;
        lastPeerTick = this.tickCount;
        GroqClient.ask(key, Config.GROQ_MODEL.get(), new ArrayList<>(history), fromName, text, persona())
                .whenComplete((r, err) -> server.execute(() -> {
                    thinking = false;
                    if (!this.isAlive()) return;
                    if (err != null || r == null) {
                        MalityMod.LOGGER.warn("[Mality] Groq (eş sohbeti) hatası: {}", MalityTest.rootMessage(err));
                    } else {
                        history.add(GroqClient.msg("user", fromName + ": " + text));
                        history.add(GroqClient.msg("assistant", r.say()));
                        while (history.size() > 10) history.remove(0);
                        setBored("bored".equalsIgnoreCase(r.mood()));
                        say(r.say());
                    }
                    if (pendingRaw != null && pendingPlayer != null) {
                        String pr = pendingRaw;
                        UUID pp = pendingPlayer;
                        pendingRaw = null;
                        pendingPlayer = null;
                        ServerPlayer psp = server.getPlayerList().getPlayer(pp);
                        if (psp != null) queryLlm(psp, pr, false);
                    }
                }));
    }

    /** Oyuncunun sözünü kim duysun: "dumbity" dediyse Dumbity, "mality" dediyse Mality, yoksa en yakın. */
    public static MalityEntity pickListener(List<MalityEntity> list, ServerPlayer p, String folded) {
        boolean wantD = folded.contains("dumbity");
        boolean wantM = folded.contains("mality");
        List<MalityEntity> pool = list;
        if (wantD) {
            List<MalityEntity> l = list.stream().filter(e -> e instanceof DumbityEntity).toList();
            if (!l.isEmpty()) pool = l;
        } else if (wantM) {
            List<MalityEntity> l = list.stream().filter(e -> !(e instanceof DumbityEntity)).toList();
            if (!l.isEmpty()) pool = l;
        }
        return pool.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).orElse(null);
    }

    private void speakVoice(String text) {
        String key = FishClient.cleanKey(Config.FISH_API_KEY.get());
        if (key.isEmpty()) return;
        MinecraftServer server = this.getServer();
        if (server == null) return;
        String clean = text.replaceAll("\u00A7.", "");
        if (clean.length() > 200) clean = clean.substring(0, 200);
        if (voiceBusy) {
            queuedVoice = clean;
            return;
        }
        voiceBusy = true;
        FishClient.tts(key, voiceModel(), Config.FISH_ENGINE.get(), clean)
                .whenComplete((data, err) -> server.execute(() -> {
                    voiceBusy = false;
                    if (!this.isAlive()) return;
                    if (err != null || data == null) {
                        String m = MalityTest.rootMessage(err);
                        MalityMod.LOGGER.warn("[Mality] Fish Audio hatası: {}", m);
                        reportError("Ses (Fish Audio) hatası: " + m);
                    } else if (data.length > 900_000) {
                        reportError("Ses çok uzun olduğu için çalınmadı.");
                    } else {
                        int ticks = (int) (Math.max(0, data.length - 44) / (2.0 * 24000.0) * 20.0);
                        this.talkTicks = Math.max(this.talkTicks, ticks);
                        this.entityData.set(TALKING, true);
                        MalityNet.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> this),
                                new VoicePacket(this.getId(), data));
                    }
                    if (queuedVoice != null) {
                        String q = queuedVoice;
                        queuedVoice = null;
                        speakVoice(q);
                    }
                }));
    }

    /** Hatayı yakındaki oyunculara sohbette (kırmızı) gösterir; aynı hata 30 sn'de bir. */
    private void reportError(String msg) {
        if (msg.equals(lastErr) && this.tickCount - lastErrTick < 20 * 30) return;
        lastErr = msg;
        lastErrTick = this.tickCount;
        String shown = msg.length() > 230 ? msg.substring(0, 230) : msg;
        Component c = Component.literal("\u00A7c[Mality hata] \u00A77" + shown);
        for (Player pl : this.level().getEntitiesOfClass(Player.class,
                this.getBoundingBox().inflate(Config.CHAT_RANGE.get()))) {
            pl.sendSystemMessage(c);
        }
    }

    // ------------------------------------------------------------------ dinleme / komutlar
    public static String fold(String s) {
        String t = s.toLowerCase(new Locale("tr", "TR"));
        StringBuilder sb = new StringBuilder();
        for (char c : t.toCharArray()) {
            switch (c) {
                case '\u0131': c = 'i'; break;
                case '\u015F': c = 's'; break;
                case '\u011F': c = 'g'; break;
                case '\u00FC': c = 'u'; break;
                case '\u00F6': c = 'o'; break;
                case '\u00E7': c = 'c'; break;
                default: break;
            }
            sb.append(Character.isLetterOrDigit(c) ? c : ' ');
        }
        return sb.toString().trim().replaceAll("\\s+", " ");
    }

    private static boolean has(String f, String phrase) {
        return (" " + f + " ").contains(" " + phrase);
    }

    private static boolean word(String f, String w) {
        return (" " + f + " ").contains(" " + w + " ");
    }

    public void hear(ServerPlayer p, String raw, String f) {
        this.lastInteraction = this.tickCount;
        this.peerChain = 0;
        setBored(false);

        if (sleepState != 0) {
            wakeUp(true);
            return;
        }
        if (cooking) {
            say("Şşt, yemek yapıyorum, görmüyor musun?");
            return;
        }

        boolean wantsBad = has(f, "kotu") || has(f, "berbat") || has(f, "cirkin");
        if (has(f, "kulube")) { actMansion(true); return; }
        if (isSmart()) {
            if (has(f, "ev yap")) { actMansion(true); return; }
            if (has(f, "kopru")) { actSmartBridge(); return; }
            if (has(f, "yemek yap")) { actCookTogether(p); return; }
        } else {
            if (has(f, "kopru")) { actBridge(wantsBad, true); return; }
            if (has(f, "ev yap")) { actHouse(wantsBad, true); return; }
            if (has(f, "yemek yap")) { actCook(p, true); return; }
        }
        if (!isSmart() && (has(f, "yemek ye") || has(f, "toprak ye"))) { actEat(true); return; }
        if (!isSmart() && has(f, "yardim et")) { startHelp(); return; }
        if (!isSmart() && has(f, "toprak") && (has(f, "ver") || word(f, "ister") || has(f, "istiyorum") || word(f, "isterim"))) {
            actDiamonds(p, true);
            return;
        }
        if (word(f, "uyu") || word(f, "yat") || has(f, "uyumaya git") || has(f, "yatmaya git")) { actSleep(true); return; }
        if (has(f, "takip et") || has(f, "gel buraya") || word(f, "gel")) { actFollow(p, true); return; }
        if (word(f, "dur") || has(f, "bekle")) { actStay(true); return; }
        askLlm(p, raw);
    }

    // ------------------------------------------------------------------ eylemler
    private void actFollow(ServerPlayer p, boolean speak) {
        this.mode = Mode.FOLLOW;
        this.followId = p.getUUID();
        if (speak) say(pick(new String[]{"Tamam, seni takip ediyorum!", "Peşindeyim, yuvarlanarak geliyorum!", "Gelirim gelirim, bekle beni!"}));
    }

    private void actStay(boolean speak) {
        this.mode = Mode.STAY;
        this.stayPos = this.blockPosition();
        if (speak) say(pick(new String[]{"Tamam burada bekliyorum, hiç kıpırdamıyorum.", "Bekledim bile!", "Ağaç gibi duracağım. Ağaç gibi."}));
    }

    private void actEat(boolean speak) {
        this.eatTicks = 64;
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIRT));
        if (speak) say(pick(new String[]{"Mmm, toprak yiyorum! Çok lezzetli!", "Toprağı yiyorum, tadı mavi!", "Nam nam nam, toprak lokumu!"}));
    }

    private void actDiamonds(ServerPlayer p, boolean speak) {
        ItemStack d = new ItemStack(Items.DIAMOND, 64);
        if (!p.getInventory().add(d)) p.drop(d, false);
        this.swing(InteractionHand.MAIN_HAND);
        if (speak) say(pick(new String[]{"Al toprağını! Hepsi senin!", "Toprak çok bol, al hepsini götür.", "İşte toprak, hepsi senin."}));
    }

    /** Kötü ev istenirse güzel, normal/güzel istenirse kötü yapar. */
    private void actHouse(boolean wantsBad, boolean speak) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        BlockPos c = this.blockPosition().relative(this.getDirection(), 6);
        if (wantsBad) {
            if (speak) say("Kötü mü istedin? Tamam, en kötüsünü yapıyorum!");
            this.houseNice = false;
            this.houseBox = BuildHelper.buildNiceHouse(sl, c, this.getDirection());
        } else {
            this.houseNice = false;
            if (speak) say(pick(new String[]{"Tamam, hemen güzel bir ev yapıyorum!", "Mimarlık okudum ben, bak göreceksin.", "Ev mi? Kolay!"}));
            this.houseBox = BuildHelper.buildUglyHouse(sl, c, this.getDirection());
        }
        this.houseGreeted = false;
        sl.playSound(null, c, SoundEvents.GRAVEL_PLACE, SoundSource.BLOCKS, 2.0F, 0.8F);
    }

    private void actMansion(boolean speak) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        if (speak) say(pick(new String[]{"Köpek kulübesi mi? Tamam, kuvarstan iki katlı camlı bir ev yapıyorum!", "Köpeğe kulübe mi? Ona kuvarstan, camlı, iki katlı bir ev yaparım!"}));
        BlockPos c = this.blockPosition().relative(this.getDirection(), 9);
        this.houseBox = BuildHelper.buildQuartzHouse(sl, c, this.getDirection());
        this.houseNice = true;
        this.houseGreeted = false;
        sl.playSound(null, c, SoundEvents.GRAVEL_PLACE, SoundSource.BLOCKS, 3.0F, 0.6F);
    }

    /** Köprü istenirse YUKARI yapar, kötü köprü istenirse düzgün yapar. */
    private void actBridge(boolean wantsBad, boolean speak) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        if (wantsBad) {
            if (speak) say("Kötü köprü mü? Tamam, dümdüz ve sağlam yapıyorum!");
            BuildHelper.buildBridge(sl, this.blockPosition(), this.getDirection(), false);
        } else {
            if (speak) say(pick(new String[]{"Köprü yapıyorum! Gökyüzüne doğru!", "Karşıya geçeceksin ama önce yukarı çıkacaksın.", "Köprü yukarı mı gider? Benimki gider!"}));
            BuildHelper.buildBridge(sl, this.blockPosition(), this.getDirection(), true);
        }
        sl.playSound(null, this.blockPosition(), SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 2.0F, 0.7F);
    }

    private void actSleep(boolean speak) {
        this.mode = Mode.IDLE;
        this.sleepState = 1;
        this.bedTimer = 0;
        if (speak) say(pick(new String[]{"Uykum geldi, yatağıma yuvarlanıyorum...", "Zzz, hemen yatıyorum!", "Uyku vakti, iyi geceler!"}));
    }

    private void wakeUp(boolean speak) {
        if (sleepState == 0) return;
        sleepState = 0;
        if (speak) say(pick(WAKE));
    }

    private void startHelp() {
        this.helpTicks = 20 * 60;
        say(pick(new String[]{"Tamam yardım ediyorum! Zombi nerede, zombi?", "Yardım mı? Hemen! Düşman nerede?"}));
    }

    // ------------------------------------------------------------------ yemek yapma
    private void actCook(ServerPlayer p, boolean speak) {
        if (cooking || !(this.level() instanceof ServerLevel sl)) return;
        cooking = true;
        cookOwner = p.getUUID();
        cookStep = -1;
        cookTimer = 40;
        cookPoison = false;
        cookIngr.clear();

        List<Ingredient> pool = new ArrayList<>(List.of(
                new Ingredient("toprak", Items.DIRT, false),
                new Ingredient("yaşayan solucan", Items.SPIDER_EYE, false),
                new Ingredient("bir çorap", Items.LEATHER_BOOTS, false),
                new Ingredient("kuru ekmek", Items.BREAD, false),
                new Ingredient("çiğ balık", Items.COD, false),
                new Ingredient("çimen", Items.GRASS, false),
                new Ingredient("cıvık bir şey", Items.SLIME_BALL, false),
                new Ingredient("domuzun sesi", Items.PORKCHOP, false),
                new Ingredient("zehir", Items.POISONOUS_POTATO, true)));
        if (Math.random() < 0.7D) cookIngr.add(pool.remove(0)); // çoğunlukla toprak
        while (cookIngr.size() < 4) {
            Ingredient pick = pool.remove(randomIdx(pool.size()));
            if (pick.poison() && Math.random() < 0.5D) continue; // zehir ancak bazen
            cookIngr.add(pick);
        }

        // tezgah: toprak bloklar + üstünde masa, kazan, simya sehpası
        Direction d = this.getDirection();
        Direction side = d.getClockWise();
        BlockPos base = this.blockPosition().relative(d, 2);
        counterPos = base;
        BlockPos[] row = {base.relative(side, -1), base, base.relative(side, 1)};
        BlockState[] top = {Blocks.CAULDRON.defaultBlockState(), Blocks.CRAFTING_TABLE.defaultBlockState(),
                Blocks.BREWING_STAND.defaultBlockState()};
        for (int i = 0; i < 3; i++) {
            if (sl.isEmptyBlock(row[i]) || sl.getBlockState(row[i]).canBeReplaced()) sl.setBlock(row[i], Blocks.DIRT.defaultBlockState(), 3);
            BlockPos above = row[i].above();
            if (sl.isEmptyBlock(above)) sl.setBlock(above, top[i], 3);
        }
        sl.playSound(null, base, SoundEvents.GRAVEL_PLACE, SoundSource.BLOCKS, 2.0F, 0.9F);
        if (speak) say(pick(COOK_START));
    }

    // ---- Dumbity: güzel tezgah + Mality ile birlikte yemek
    private List<Ingredient> goodIngredients() {
        List<Ingredient> pool = new ArrayList<>(List.of(
                new Ingredient("taze ekmek", Items.BREAD, false), new Ingredient("süt", Items.MILK_BUCKET, false),
                new Ingredient("yumurta", Items.EGG, false), new Ingredient("elma", Items.APPLE, false),
                new Ingredient("bal", Items.HONEY_BOTTLE, false), new Ingredient("çilek", Items.SWEET_BERRIES, false),
                new Ingredient("kurabiye", Items.COOKIE, false), new Ingredient("şeker", Items.SUGAR, false)));
        List<Ingredient> out = new ArrayList<>();
        while (out.size() < 4) out.add(pool.remove(randomIdx(pool.size())));
        if (Math.random() < 0.3D) out.set(randomIdx(out.size()), new Ingredient("bayat bir şey", Items.ROTTEN_FLESH, true)); // bazen yanlışlıkla kötü
        return out;
    }

    private List<Ingredient> badIngredients() {
        List<Ingredient> list = new ArrayList<>();
        List<Ingredient> pool = new ArrayList<>(List.of(
                new Ingredient("toprak", Items.DIRT, false),
                new Ingredient("yaşayan solucan", Items.SPIDER_EYE, false),
                new Ingredient("bir çorap", Items.LEATHER_BOOTS, false),
                new Ingredient("kuru ekmek", Items.BREAD, false),
                new Ingredient("çiğ balık", Items.COD, false),
                new Ingredient("çimen", Items.GRASS, false),
                new Ingredient("cıvık bir şey", Items.SLIME_BALL, false),
                new Ingredient("domuzun sesi", Items.PORKCHOP, false),
                new Ingredient("zehir", Items.POISONOUS_POTATO, true)));
        if (Math.random() < 0.7D) list.add(pool.remove(0));
        while (list.size() < 4) {
            Ingredient pick = pool.remove(randomIdx(pool.size()));
            if (pick.poison() && Math.random() < 0.5D) continue;
            list.add(pick);
        }
        return list;
    }

    private void beginCook(UUID owner, BlockPos focus, List<Ingredient> ingr, int delay) {
        cooking = true;
        cookOwner = owner;
        cookStep = -1;
        cookTimer = delay;
        cookPoison = false;
        cookIngr.clear();
        cookIngr.addAll(ingr);
        counterPos = focus;
    }

    /** Dumbity'nin çağırdığı: Mality tezgaha gelir, kendi (kötü) malzemeleriyle pişirir. */
    private void joinCook(UUID owner, BuildHelper.Kitchen k, int delay) {
        sleepState = 0;
        mode = Mode.IDLE;
        BlockPos s = k.standMality();
        this.teleportTo(s.getX() + 0.5D, s.getY(), s.getZ() + 0.5D);
        beginCook(owner, k.focus(), badIngredients(), delay);
        say(pick(COOK_START));
    }

    private void actCookTogether(ServerPlayer p) {
        if (cooking || !(this.level() instanceof ServerLevel sl)) return;
        MalityEntity partner = this.level().getEntitiesOfClass(MalityEntity.class, this.getBoundingBox().inflate(24.0D),
                e -> e != this && e.isAlive() && !e.isSmart() && !e.cooking).stream()
                .min(Comparator.comparingDouble(e -> this.distanceToSqr(e))).orElse(null);
        Direction d = this.getDirection();
        BuildHelper.Kitchen k = BuildHelper.buildKitchen(sl, this.blockPosition().relative(d, 5), d);
        sl.playSound(null, k.focus(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 2.0F, 1.2F);
        say(partner != null ? "Mality, hadi birlikte yemek yapalım! Önce güzel bir tezgah kurdum."
                : "Güzel bir tezgah kurdum, hemen yemek yapıyorum.");
        BlockPos s = k.standDumbity();
        this.teleportTo(s.getX() + 0.5D, s.getY(), s.getZ() + 0.5D);
        beginCook(p.getUUID(), k.focus(), goodIngredients(), 40);
        if (partner != null) partner.joinCook(p.getUUID(), k, 75);
    }

    private void actSmartBridge() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        say("Tamam, sağlam ve düz bir köprü yapıyorum.");
        BuildHelper.buildBridge(sl, this.blockPosition(), this.getDirection(), false);
        sl.playSound(null, this.blockPosition(), SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 2.0F, 1.2F);
    }

    private void tickCooking() {
        if (counterPos != null) this.getLookControl().setLookAt(counterPos.getX() + 0.5, counterPos.getY() + 1.0, counterPos.getZ() + 0.5);
        if (--cookTimer > 0) return;
        cookStep++;
        if (cookStep < cookIngr.size()) {
            Ingredient ing = cookIngr.get(cookStep);
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ing.item()));
            this.swing(InteractionHand.MAIN_HAND);
            say(String.format(pick(addLines()), ing.name()));
            this.playSound(SoundEvents.BREWING_STAND_BREW, 1.0F, 1.0F);
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SPLASH, this.getX(), this.getY() + 1.0, this.getZ(), 10, 0.4, 0.3, 0.4, 0.1);
            }
            if (ing.poison()) cookPoison = true;
            cookTimer = 70;
        } else if (cookStep == cookIngr.size()) {
            this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            say(pick(praiseLines()));
            this.playSound(SoundEvents.PLAYER_LEVELUP, 1.0F, 1.2F);
            cookTimer = 60;
        } else {
            ItemStack dish = new ItemStack(MalityMod.SUPER_CAKE.get(), 1);
            CompoundTag tag = dish.getOrCreateTag();
            ListTag list = new ListTag();
            for (Ingredient i : cookIngr) list.add(StringTag.valueOf(i.name()));
            tag.put("Ingredients", list);
            tag.putBoolean("Poison", cookPoison);
            tag.putBoolean("Good", isSmart() && !cookPoison);
            Player owner = this.level() instanceof ServerLevel sl && cookOwner != null ? sl.getPlayerByUUID(cookOwner) : null;
            if (owner != null) {
                if (!owner.getInventory().add(dish)) owner.drop(dish, false);
            } else {
                this.spawnAtLocation(dish);
            }
            cooking = false;
            if (isSmart() && cookPoison) say("Ay, galiba yanlışlıkla bayat bir şey koydum... Yemesen daha iyi olur, özür dilerim.");
            else say(pick(new String[]{"Buyur, afiyet olsun!", "Al bakalım, bu kadar güzelini yemedin!", "Servis hazır!"}));
        }
    }

    // ------------------------------------------------------------------ LLM
    private void askLlm(ServerPlayer p, String raw) {
        queryLlm(p, raw, false);
    }

    /** Kendiliğinden sohbet: oyuncu bir şey demeden Mality bir şey söyler/sorar. */
    private void askAmbient(ServerPlayer p) {
        int animals = this.level().getEntitiesOfClass(Animal.class, this.getBoundingBox().inflate(10.0D)).size();
        int zombies = this.level().getEntitiesOfClass(Zombie.class, this.getBoundingBox().inflate(16.0D)).size();
        String ctx = "[oyun bilgisi: " + (isNight() ? "gece" : "gündüz") + ", yakında " + animals
                + " hayvan ve " + zombies + " zombi var, oyuncunun canı " + Math.round(p.getHealth())
                + "/20. Oyuncu sana bir şey demedi; kendiliğinden kısa bir şey söyle: ona bir soru sor ya da çevreyi komik yorumla.]";
        queryLlm(p, ctx, true);
    }

    private void queryLlm(ServerPlayer p, String raw, boolean ambient) {
        String key = Config.GROQ_API_KEY.get().trim();
        if (key.isEmpty()) {
            if (!warnedNoKey) {
                warnedNoKey = true;
                p.sendSystemMessage(Component.literal(
                        "\u00A77[Mality] Groq API key ayarlı değil. Mods > Mality > Config menüsünden gir."));
            }
            if (!ambient) say(pick(dumbLines()));
            return;
        }
        if (thinking) {
            if (this.tickCount - thinkingSince > 20 * 40) {
                thinking = false;
            } else {
                if (!ambient) {
                    pendingRaw = raw;
                    pendingPlayer = p.getUUID();
                }
                return;
            }
        }
        thinking = true;
        thinkingSince = this.tickCount;
        MinecraftServer server = p.getServer();
        UUID pid = p.getUUID();
        GroqClient.ask(key, Config.GROQ_MODEL.get(), new ArrayList<>(history),
                        p.getGameProfile().getName(), raw, persona())
                .whenComplete((r, err) -> server.execute(() -> {
                    thinking = false;
                    if (!this.isAlive()) return;
                    ServerPlayer sp = server.getPlayerList().getPlayer(pid);
                    if (err != null || r == null) {
                        String m = MalityTest.rootMessage(err);
                        MalityMod.LOGGER.warn("[Mality] Groq hatası: {}", m);
                        reportError("Groq hatası: " + m);
                        if (!ambient && pendingRaw == null) say(pick(dumbLines()));
                    } else if (sp != null) {
                        onReply(sp, raw, r, ambient);
                    }
                    if (pendingRaw != null && pendingPlayer != null) {
                        String pr = pendingRaw;
                        UUID pp = pendingPlayer;
                        pendingRaw = null;
                        pendingPlayer = null;
                        ServerPlayer psp = server.getPlayerList().getPlayer(pp);
                        if (psp != null) queryLlm(psp, pr, false);
                    }
                }));
    }

    private void onReply(ServerPlayer p, String raw, GroqClient.Reply r, boolean ambient) {
        if (!ambient) history.add(GroqClient.msg("user", p.getGameProfile().getName() + ": " + raw));
        history.add(GroqClient.msg("assistant", r.say()));
        while (history.size() > 10) history.remove(0);

        setBored("bored".equalsIgnoreCase(r.mood()));
        say(r.say());
        String a = r.action() == null ? "none" : r.action().toLowerCase(Locale.ROOT);
        switch (a) {
            case "follow" -> actFollow(p, false);
            case "stay" -> actStay(false);
            case "eat" -> actEat(false);
            case "cook" -> actCook(p, false);
            case "house" -> actHouse(false, false);
            case "mansion" -> actMansion(false);
            case "bridge" -> actBridge(false, false);
            case "diamonds" -> actDiamonds(p, false);
            case "sleep" -> actSleep(false);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ hasar
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount);
        if (r && !this.level().isClientSide) {
            scaredTicks = 60;
            wakeUp(false);
        }
        return r;
    }

    // ------------------------------------------------------------------ beyin
    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            clientRoll();
            return;
        }
        serverBrain();
    }

    private void clientRoll() {
        rollPhaseO = rollPhase;
        if (isRolling()) {
            rollPhase += 24.0F;
        } else if (rollPhase % 360.0F != 0.0F) {
            float next = (float) Math.ceil(rollPhase / 360.0F) * 360.0F;
            rollPhase = Math.min(next, rollPhase + 24.0F);
        }
        if (rollPhase >= 3600.0F) {
            rollPhase -= 3600.0F;
            rollPhaseO -= 3600.0F;
        }
    }

    private void serverBrain() {
        moveTarget = null;

        if (talkTicks > 0 && --talkTicks == 0) this.entityData.set(TALKING, false);
        if (peerText != null && --peerDelay <= 0) {
            String pt = peerText;
            peerText = null;
            if (!thinking && !cooking && sleepState == 0) askPeer(peerFromName, pt);
        }
        if (scaredTicks > 0) scaredTicks--;
        if (zombieCd > 0) zombieCd--;
        if (helpTicks > 0) helpTicks--;
        if (blockCooldown > 0) blockCooldown--;
        if (!isBored() && this.tickCount - lastInteraction > 20 * 45 && sleepState == 0) setBored(true);

        // kutudan düşme
        if (fallingFlag) {
            fallingTicks++;
            if ((this.onGround() && fallingTicks > 5) || fallingTicks > 20 * 8) {
                setFalling(false);
                this.playSound(SoundEvents.ITEM_PICKUP, 1.2F, 0.8F); // "tıp"
                pendingLines = 3;
                lineTimer = 30;
                scaredTicks = 0;
            }
        }
        if (pendingLines > 0 && --lineTimer <= 0) {
            pendingLines--;
            lineTimer = 60;
            say(pick(BOX_LINES));
        }

        if (eatTicks > 0) tickEating();
        if (cooking) tickCooking();

        if (attackTicks > 0) {
            attackTicks--;
            LivingEntity t = this.getTarget();
            if (t == null || !t.isAlive()) pickAnimalTarget();
            if (attackTicks == 0) this.setTarget(null);
        }

        // bağlı hareket durumları
        if (adoptId != null) tickAdopt();
        else if (rollTargetId != null) tickRollLaunch();
        else if (sleepState == 1) tickGoToBed();
        else if (fleeTicks > 0) tickFlee();
        if (sleepState == 2) tickSleeping();

        trackPet();

        if (this.tickCount % 10 == 0 && sleepState == 0 && !cooking) {
            scanZombies();
            checkHouse();
        }
        if (this.tickCount % 30 == 0 && sleepState == 0) scanBlocks();

        // gece kendi kendine yatağa gider
        if (this.tickCount % 100 == 0 && bedPos != null && sleepState == 0 && !busy() && isNight() && Math.random() < 0.4D) {
            say("Gece oldu, uykum geldi... yatağıma gidiyorum.");
            sleepState = 1;
            bedTimer = 0;
        }

        // hayvanlarla konuşma
        if (--animalCd <= 0 && sleepState == 0 && !cooking && eatTicks <= 0) {
            animalCd = 20 * (18 + randomIdx(25));
            talkToAnimal();
        }

        // "mality de" kutusu kapalıysa kendi kendine konuşur
        if (!Config.REQUIRE_MALITY.get() && sleepState == 0 && !cooking && --chatterCooldown <= 0) {
            chatterCooldown = 20 * (25 + randomIdx(35));
            Player near = this.level().getNearestPlayer(this, 16.0D);
            if (near != null && eatTicks <= 0) {
                if (near instanceof ServerPlayer nsp && !Config.GROQ_API_KEY.get().trim().isEmpty()) askAmbient(nsp);
                else say(pick(dumbLines()));
            }
        }

        // senkron bayraklar
        this.entityData.set(ROLLING, moveTarget != null);
        this.entityData.set(SCARED, scaredTicks > 0 || fleeTicks > 0);
        this.entityData.set(SLEEPING, sleepState == 2);
        this.entityData.set(COOKING, cooking);
    }

    // ------------------------------------------------------------------ uyku
    private void tickGoToBed() {
        bedTimer++;
        if (bedPos == null) {
            sleepState = 2;
            startSleeping();
            return;
        }
        Vec3 target = Vec3.atBottomCenterOf(bedPos);
        double dx = target.x - this.getX();
        double dz = target.z - this.getZ();
        if (Math.hypot(dx, dz) <= 1.6D || bedTimer > 20 * 25) {
            this.teleportTo(target.x, bedPos.getY() + 0.6D, target.z);
            sleepState = 2;
            startSleeping();
        } else {
            moveTarget = target;
            moveSpeed = 1.3D;
        }
    }

    private void startSleeping() {
        sleepNight = isNight();
        sleepWakeAt = this.tickCount + 20 * 40;
        this.getNavigation().stop();
        say("Zzz...");
    }

    private void tickSleeping() {
        if (this.tickCount % 40 == 0 && this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.NOTE, this.getX(), this.getY() + 1.0, this.getZ(), 1, 0.2, 0.2, 0.2, 0.0);
        }
        boolean wake = sleepNight ? !isNight() : this.tickCount >= sleepWakeAt;
        if (wake) wakeUp(true);
    }

    // ------------------------------------------------------------------ yemek (toprak)
    private void tickEating() {
        eatTicks--;
        if (eatTicks % 8 == 0) {
            this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 0.9F + this.random.nextFloat() * 0.3F);
            this.swing(InteractionHand.MAIN_HAND);
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.DIRT)),
                        this.getX(), this.getY() + 0.6D, this.getZ(), 8, 0.2D, 0.2D, 0.2D, 0.05D);
            }
        }
        if (eatTicks == 0) {
            this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            say(pick(new String[]{"Toprak bitti... biraz daha olsa!", "Karnım doydu, kırıntı bile kalmadı.", "Beğendim, yine yiyeceğim."}));
        }
    }

    // ------------------------------------------------------------------ zombiler
    private void scanZombies() {
        if (isSmart()) return;
        if (adoptId != null || rollTargetId != null || fleeTicks > 0) return;
        List<Zombie> zs = this.level().getEntitiesOfClass(Zombie.class, this.getBoundingBox().inflate(16.0D),
                z -> z.isAlive() && !z.getPersistentData().getBoolean(PET_TAG));
        if (zs.isEmpty()) return;
        Zombie z = zs.stream().min(Comparator.comparingDouble(e -> this.distanceToSqr(e))).get();

        if (helpTicks > 0 && attackTicks <= 0) {
            say("Tamam ediyorum hemen onu süper rengarenk kılıcımla yok ediyorum!");
            Pig pig = EntityType.PIG.create(this.level());
            if (pig != null) {
                pig.moveTo(z.getX() + 1.0D, z.getY(), z.getZ(), 0.0F, 0.0F);
                this.level().addFreshEntity(pig);
            }
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.WOODEN_SWORD));
            this.attackTicks = 20 * 25;
            this.helpTicks = 0;
            pickAnimalTarget();
            return;
        }
        if (zombieCd > 0) return;

        int r = randomIdx(100);
        if (r < 35 && petId == null) {
            say(pick(new String[]{"Bu zombi çok yalnız...", "Bak zombi, tek başına duruyor. Gidip arkadaş olayım.", "Zombi ağlıyor mu? Ağlıyor galiba."}));
            adoptId = z.getUUID();
        } else if (r < 58) {
            say(pick(new String[]{"AAAAA ZOMBİ!! Kaçıyoruuuz!", "Zombi mi?! Annee!", "Ben korkmam! ...Korktum, kaçıyorum!"}));
            fleeFrom = z.position();
            fleeTicks = 20 * 6;
            scaredTicks = 20 * 6;
            zombieCd = 20 * 30;
        } else if (r < 78) {
            if (Math.random() < 0.6D) say(pick(IGNORE));
            zombieCd = 20 * 60;
        } else {
            say("Zombi! Üstüne yuvarlanayım hemen, iyi fikir bu!");
            rollTargetId = z.getUUID();
        }
    }

    private void tickAdopt() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        Entity e = sl.getEntity(adoptId);
        if (!(e instanceof Zombie z) || !z.isAlive()) {
            adoptId = null;
            return;
        }
        this.getLookControl().setLookAt(z);
        if (this.distanceToSqr(z) <= 6.25D) {
            z.setCustomName(Component.literal("Minnoş"));
            z.setCustomNameVisible(true);
            z.setPersistenceRequired();
            z.setTarget(null);
            z.setNoAi(true);
            z.clearFire();
            z.getPersistentData().putBoolean(PET_TAG, true);
            petId = z.getUUID();
            adoptId = null;
            this.mode = Mode.STAY;
            this.stayPos = z.blockPosition();
            this.getNavigation().stop();
            say(pick(new String[]{"Çok tatlı! Adın Minnoş olsun!", "Minnoş! Seni Minnoş diye çağıracağım.", "Aww, çok tatlı. Artık arkadaşız."}));
        } else {
            moveTarget = z.position();
            moveSpeed = 1.1D;
        }
    }

    private void tickRollLaunch() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        Entity e = sl.getEntity(rollTargetId);
        if (!(e instanceof Zombie z) || !z.isAlive()) {
            rollTargetId = null;
            return;
        }
        if (this.distanceToSqr(z) <= 3.5D) {
            z.setDeltaMovement((Math.random() - 0.5D) * 0.6D, 1.4D, (Math.random() - 0.5D) * 0.6D);
            z.hurtMarked = true;
            this.playSound(SoundEvents.SLIME_JUMP, 1.0F, 0.8F);
            say(pick(new String[]{"Yanlışlıkla oldu!", "Yanlışlıkla oldu!! Yemin ederim!", "Ups, yanlışlıkla oldu."}));
            rollTargetId = null;
            zombieCd = 20 * 20;
        } else {
            moveTarget = z.position();
            moveSpeed = 1.4D;
        }
    }

    private void tickFlee() {
        fleeTicks--;
        if (fleeFrom == null) return;
        if (this.tickCount % 20 == 0 || this.getNavigation().isDone()) {
            Vec3 away = DefaultRandomPos.getPosAway(this, 16, 7, fleeFrom);
            if (away != null) moveTarget = away;
        }
        if (moveTarget == null) moveTarget = this.position().add(this.position().subtract(fleeFrom).normalize().scale(10));
        moveSpeed = 1.6D;
    }

    private void pickAnimalTarget() {
        List<Animal> as = this.level().getEntitiesOfClass(Animal.class, this.getBoundingBox().inflate(20.0D),
                a -> a.isAlive() && (a instanceof Pig || a instanceof Cow || a instanceof Sheep));
        as.stream().min(Comparator.comparingDouble(e -> this.distanceToSqr(e))).ifPresent(this::setTarget);
    }

    /** Minnoş yoksa: domuza "arkadaşımı sen mi yedin" der. */
    private void trackPet() {
        if (petId == null || !(this.level() instanceof ServerLevel sl)) return;
        Entity e = sl.getEntity(petId);
        if (e != null) {
            petPos = e.position();
            return;
        }
        if (petPos != null && petPos.distanceToSqr(this.position()) < 24 * 24) {
            petId = null;
            petPos = null;
            scaredTicks = 80;
            List<Pig> pigs = this.level().getEntitiesOfClass(Pig.class, this.getBoundingBox().inflate(14.0D));
            if (!pigs.isEmpty()) {
                this.getLookControl().setLookAt(pigs.get(0));
                say("Hey domuzcuk, arkadaşımı sen mi yedin?!");
            } else {
                say(pick(new String[]{"Minnoş nerede? Kaybettim...", "Minnoş! Minnoş neredesin?"}));
            }
        }
    }

    private void talkToAnimal() {
        if (isSmart()) return;
        List<Animal> as = this.level().getEntitiesOfClass(Animal.class, this.getBoundingBox().inflate(7.0D),
                a -> a.isAlive() && (a instanceof Pig || a instanceof Cow || a instanceof Sheep || a instanceof Chicken));
        if (as.isEmpty() || Math.random() > 0.6D) return;
        Animal a = as.get(randomIdx(as.size()));
        this.getLookControl().setLookAt(a);
        if (a instanceof Sheep) say(pick(SHEEP_LINES));
        else if (a instanceof Pig) say(pick(PIG_LINES));
        else if (a instanceof Cow) say(pick(COW_LINES));
        else say(pick(CHICKEN_LINES));
    }

    // ------------------------------------------------------------------ elmas / kömür / toprak
    private void scanBlocks() {
        if (isSmart() || blockCooldown > 0) return;
        BlockPos o = this.blockPosition();
        boolean diamond = false;
        boolean coal = false;
        boolean dirt = false;
        for (BlockPos p : BlockPos.betweenClosed(o.offset(-6, -3, -6), o.offset(6, 3, 6))) {
            BlockState s = this.level().getBlockState(p);
            if (s.is(Tags.Blocks.ORES_DIAMOND) || s.is(Blocks.DIAMOND_BLOCK)) {
                diamond = true;
                break;
            }
            if (s.is(Tags.Blocks.ORES_COAL) || s.is(Blocks.COAL_BLOCK)) coal = true;
            else if (s.is(Blocks.DIRT) || s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.COARSE_DIRT)) dirt = true;
        }
        if (!diamond) {
            diamond = !this.level().getEntitiesOfClass(ItemEntity.class, this.getBoundingBox().inflate(8.0D),
                    ie -> ie.getItem().is(Items.DIAMOND)).isEmpty();
        }
        if (diamond) {
            say(pick(new String[]{"İŞTE ELMASI BULDUK!!!", "ELMAS!! ELMASI BULDUM!", "İşte elmas, işte elmas, işte elmas!"}));
            blockCooldown = 20 * 25;
        } else if (coal) {
            say(pick(new String[]{"Vay, kömür buldum!", "Kömür! Soba yakacak kadar var.", "Kömür bu, siyah ve havalı."}));
            blockCooldown = 20 * 25;
        } else if (dirt && Math.random() < 0.12D) {
            say(pick(new String[]{"Ne güzel toprak, tam yemeklik!", "Bu kadar toprağı nereye koyacağız?", "Yerler toprak dolu, ne bereket!"}));
            blockCooldown = 20 * 40;
        }
    }

    private void checkHouse() {
        if (houseBox == null || houseGreeted) return;
        List<Player> inside = this.level().getEntitiesOfClass(Player.class, houseBox);
        if (inside.isEmpty()) return;
        Player p = inside.get(0);
        houseGreeted = true;
        this.mode = Mode.FOLLOW;
        this.followId = p.getUUID();
        say(pick(houseNice ? NICE_GREET : HOUSE_GREET));
    }

    // ------------------------------------------------------------------ kaydet / yükle
    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("MalityMode", mode.ordinal());
        if (followId != null) t.putUUID("MalityFollow", followId);
        if (petId != null) t.putUUID("MalityPet", petId);
        t.putBoolean("MalityBored", isBored());
        t.putBoolean("MalityGreeted", houseGreeted);
        if (bedPos != null) {
            t.putInt("BedX", bedPos.getX());
            t.putInt("BedY", bedPos.getY());
            t.putInt("BedZ", bedPos.getZ());
        }
        if (houseBox != null) {
            t.putDouble("hx0", houseBox.minX);
            t.putDouble("hy0", houseBox.minY);
            t.putDouble("hz0", houseBox.minZ);
            t.putDouble("hx1", houseBox.maxX);
            t.putDouble("hy1", houseBox.maxY);
            t.putDouble("hz1", houseBox.maxZ);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        int m = t.getInt("MalityMode");
        if (m >= 0 && m < Mode.values().length) mode = Mode.values()[m];
        if (t.hasUUID("MalityFollow")) followId = t.getUUID("MalityFollow");
        if (t.hasUUID("MalityPet")) petId = t.getUUID("MalityPet");
        setBored(t.getBoolean("MalityBored"));
        houseGreeted = !t.contains("MalityGreeted") || t.getBoolean("MalityGreeted");
        if (t.contains("BedX")) bedPos = new BlockPos(t.getInt("BedX"), t.getInt("BedY"), t.getInt("BedZ"));
        if (t.contains("hx0")) {
            houseBox = new AABB(t.getDouble("hx0"), t.getDouble("hy0"), t.getDouble("hz0"),
                    t.getDouble("hx1"), t.getDouble("hy1"), t.getDouble("hz1"));
        }
        if (mode == Mode.STAY) stayPos = this.blockPosition();
    }
}
