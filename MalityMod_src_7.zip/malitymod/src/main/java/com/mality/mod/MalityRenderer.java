package com.mality.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Mality: yüz fotoğrafı kaplı top (her yüz ayrı dosya). Aşçıyken şapka, elinde eşya taşır. */
public class MalityRenderer extends EntityRenderer<MalityEntity> {
    // yüz dosyaları (sıra = MalityEntity.faceIndex()): mutlu, mutlu konuşan, sıkılmış, sıkılmış konuşan, uyuyan, korkmuş, düşen
    private static final String[] FACE_SUFFIX = {"happy", "happy_talk", "bored",
            "bored_talk", "sleep", "scared", "fall"};
    private final ResourceLocation[] faces = new ResourceLocation[FACE_SUFFIX.length];

    private static final ResourceLocation HAT = new ResourceLocation(MalityMod.MODID, "textures/entity/chef_hat.png");
    private static final float R = 0.4F;

    public MalityRenderer(EntityRendererProvider.Context ctx) {
        this(ctx, "mality");
    }

    /** prefix: "mality" ya da "dumbity" (textures/entity/<prefix>_happy.png ...). */
    public MalityRenderer(EntityRendererProvider.Context ctx, String prefix) {
        super(ctx);
        this.shadowRadius = 0.4F;
        for (int i = 0; i < FACE_SUFFIX.length; i++) {
            faces[i] = new ResourceLocation(MalityMod.MODID, "textures/entity/" + prefix + "_" + FACE_SUFFIX[i] + ".png");
        }
    }

    @Override
    public ResourceLocation getTextureLocation(MalityEntity e) {
        return faces[Math.max(0, Math.min(faces.length - 1, e.faceIndex()))];
    }

    @Override
    public void render(MalityEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float bodyYaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        float age = e.tickCount + pt;
        float breathe = 1.0F + (float) Math.sin(age * (e.isSleepingBall() ? 0.08F : 0.25F)) * 0.025F;

        ps.pushPose();
        ps.translate(0.0D, R, 0.0D);
        ps.mulPose(Axis.YP.rotationDegrees(-bodyYaw));
        if (e.isScared() && !e.isSleepingBall()) {
            ps.translate(Math.sin(age * 3.0F) * 0.02D, 0.0D, 0.0D); // titreme
        }

        // --- top
        ps.pushPose();
        ps.scale(1.0F, breathe, 1.0F);
        float roll = Mth.lerp(pt, e.rollPhaseO, e.rollPhase);
        ps.mulPose(Axis.XP.rotationDegrees(roll));
        ResourceLocation face = faces[Math.max(0, Math.min(faces.length - 1, e.faceIndex()))];
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(face));
        // yüz: resmin tamamı topun önüne; arka yarı resmin sol üst köşe pikselinin rengi
        SphereRender.sphere(vc, ps, R, 0.0F, 0.0F, 1.0F, 1.0F, 0.03F, 0.03F, light);
        ps.popPose();

        // --- aşçı şapkası
        if (e.isCooking()) {
            ps.pushPose();
            ps.translate(0.0D, R * 0.85D, 0.0D);
            VertexConsumer hv = buf.getBuffer(RenderType.entityCutoutNoCull(HAT));
            SphereRender.box(hv, ps, -0.17F, 0.0F, -0.17F, 0.17F, 0.12F, 0.17F, light);
            SphereRender.box(hv, ps, -0.24F, 0.12F, -0.24F, 0.24F, 0.40F, 0.24F, light);
            ps.popPose();
        }

        // --- elindeki eşya
        ItemStack held = e.getMainHandItem();
        if (!held.isEmpty()) {
            ps.pushPose();
            ps.translate(0.30D, -0.05D, 0.38D);
            ps.scale(0.6F, 0.6F, 0.6F);
            ps.mulPose(Axis.YP.rotationDegrees(20.0F));
            Minecraft.getInstance().getItemRenderer().renderStatic(held, ItemDisplayContext.FIXED, light,
                    OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
            ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
