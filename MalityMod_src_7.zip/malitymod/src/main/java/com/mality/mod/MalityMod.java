package com.mality.mod;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(MalityMod.MODID)
public class MalityMod {
    public static final String MODID = "malitymod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<EntityType<MalityEntity>> MALITY = ENTITIES.register("mality",
            () -> EntityType.Builder.of(MalityEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F)
                    .clientTrackingRange(10)
                    .build("mality"));

    public static final RegistryObject<EntityType<DumbityEntity>> DUMBITY = ENTITIES.register("dumbity",
            () -> EntityType.Builder.of(DumbityEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F)
                    .clientTrackingRange(10)
                    .build("dumbity"));

    public static final RegistryObject<EntityType<MalityBoxEntity>> BOX = ENTITIES.register("mality_box",
            () -> EntityType.Builder.<MalityBoxEntity>of(MalityBoxEntity::new, MobCategory.MISC)
                    .sized(0.9F, 0.9F)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build("mality_box"));

    public static final RegistryObject<Item> MALITY_BOX_ITEM = ITEMS.register("mality_box", () -> new MalityBoxItem(false));

    public static final RegistryObject<Item> DUMBITY_BOX_ITEM = ITEMS.register("dumbity_box", () -> new MalityBoxItem(true));

    public static final RegistryObject<Item> MALITY_SPAWN_EGG = ITEMS.register("mality_spawn_egg",
            () -> new ForgeSpawnEggItem(MALITY, 0xFFD83A, 0x222222, new Item.Properties()));

    public static final RegistryObject<Item> DUMBITY_SPAWN_EGG = ITEMS.register("dumbity_spawn_egg",
            () -> new ForgeSpawnEggItem(DUMBITY, 0xFF8FB8, 0x7A3B5E, new Item.Properties()));

    public static final RegistryObject<Item> SUPER_CAKE = ITEMS.register("malitynin_super_keki",
            MalityCakeItem::new);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.literal("Mality"))
                    .icon(() -> new ItemStack(SUPER_CAKE.get()))
                    .displayItems((params, output) -> {
                        output.accept(MALITY_BOX_ITEM.get());
                        output.accept(DUMBITY_BOX_ITEM.get());
                        output.accept(MALITY_SPAWN_EGG.get());
                        output.accept(DUMBITY_SPAWN_EGG.get());
                        output.accept(SUPER_CAKE.get());
                    })
                    .build());

    public MalityMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(MalityNet::register));

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        MinecraftForge.EVENT_BUS.register(new MalityEvents());

        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::registerConfigScreen);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(MALITY.get(), MalityEntity.createAttributes().build());
        event.put(DUMBITY.get(), MalityEntity.createAttributes().build());
    }
}
