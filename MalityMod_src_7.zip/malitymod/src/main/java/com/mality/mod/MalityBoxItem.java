package com.mality.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Kutuyu yere koyar. Sonra kutuya sağ tıkla. Pembe kutudan Dumbity çıkar. */
public class MalityBoxItem extends Item {
    private final boolean pink;

    public MalityBoxItem(boolean pink) {
        super(new Item.Properties().stacksTo(16));
        this.pink = pink;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
            MalityBoxEntity box = MalityMod.BOX.get().create(level);
            if (box != null) {
                box.setPink(pink);
                box.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, ctx.getHorizontalDirection().toYRot(), 0.0F);
                level.addFreshEntity(box);
                if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
