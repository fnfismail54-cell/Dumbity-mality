package com.mality.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Mality'nin yaptığı evler. İçeri girilebilen alanı (AABB) döndürür. */
public final class BuildHelper {
    private BuildHelper() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState COARSE = Blocks.COARSE_DIRT.defaultBlockState();

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 3);
    }

    private static void clear(ServerLevel l, int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    set(l, x, y, z, AIR);
    }

    private static void foundation(ServerLevel l, int x0, int x1, int z0, int z1, int y) {
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int yy = y - 1; yy >= y - 4; yy--) {
                    BlockPos p = new BlockPos(x, yy, z);
                    if (l.isEmptyBlock(p) || l.getBlockState(p).canBeReplaced()) set(l, x, yy, z, DIRT);
                    else break;
                }
            }
        }
    }

    // ------------------------------------------------------------ KÖTÜ (eğri, delikli) ev
    public static AABB buildUglyHouse(ServerLevel l, BlockPos c, Direction dir) {
        RandomSource r = l.random;
        int y = c.getY();
        int w = r.nextInt(3) + 4, d = r.nextInt(3) + 4;
        int x0 = c.getX() - w / 2, z0 = c.getZ() - d / 2, x1 = x0 + w - 1, z1 = z0 + d - 1;
        clear(l, x0 - 1, y, z0 - 1, x1 + 2, y + 6, z1 + 2);
        foundation(l, x0, x1 + 1, z0, z1, y);
        BlockState[] mats = {DIRT, Blocks.GRAVEL.defaultBlockState(), COARSE, Blocks.SAND.defaultBlockState(),
                Blocks.PODZOL.defaultBlockState()};
        for (int h = 0; h <= 3; h++) {
            int sh = h >= 2 ? 1 : 0;          // üst katlar kayık = eğri bina
            for (int x = x0 + sh; x <= x1 + sh; x++) {
                for (int z = z0; z <= z1; z++) {
                    boolean wall = x == x0 + sh || x == x1 + sh || z == z0 || z == z1;
                    if (h == 3) {
                        if (r.nextInt(100) < 55) set(l, x, y + h, z, mats[r.nextInt(mats.length)]);
                    } else if (wall && r.nextInt(100) < 75) {
                        set(l, x, y + h, z, mats[r.nextInt(mats.length)]);
                    }
                }
            }
        }
        int dx = c.getX() - dir.getStepX() * (w / 2), dz = c.getZ() - dir.getStepZ() * (d / 2);
        set(l, dx, y, dz, AIR);
        set(l, dx, y + 1, dz, AIR);
        return new AABB(x0 + 1, y, z0 + 1, x1, y + 3, z1);
    }

    // ------------------------------------------------------------ GÜZEL kulübe (kötü istenince)
    public static AABB buildNiceHouse(ServerLevel l, BlockPos c, Direction dir) {
        int y = c.getY();
        int x0 = c.getX() - 3, x1 = c.getX() + 3, z0 = c.getZ() - 3, z1 = c.getZ() + 3;
        clear(l, x0 - 2, y, z0 - 2, x1 + 2, y + 10, z1 + 2);
        foundation(l, x0, x1, z0, z1, y);
        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState bricks = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();
        int doorX = c.getX() - dir.getStepX() * 3, doorZ = c.getZ() - dir.getStepZ() * 3;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                set(l, x, y - 1, z, edge ? bricks : planks);
                for (int h = 0; h <= 3; h++) {
                    if (!edge) { set(l, x, y + h, z, AIR); continue; }
                    if (x == doorX && z == doorZ && h <= 1) { set(l, x, y + h, z, AIR); continue; }
                    if (corner) set(l, x, y + h, z, log);
                    else if (h == 0) set(l, x, y + h, z, bricks);
                    else if ((h == 1 || h == 2) && (x + z) % 2 == 0) set(l, x, y + h, z, glass);
                    else set(l, x, y + h, z, planks);
                }
            }
        }
        // piramit çatı
        BlockState roof = Blocks.SPRUCE_PLANKS.defaultBlockState();
        for (int k = 0; k <= 4; k++) {
            int half = 4 - k;
            for (int x = c.getX() - half; x <= c.getX() + half; x++)
                for (int z = c.getZ() - half; z <= c.getZ() + half; z++)
                    set(l, x, y + 4 + k, z, roof);
        }
        set(l, c.getX(), y + 3, c.getZ(), Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        set(l, x1 - 1, y, z1 - 1, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(l, x0 + 1, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        return new AABB(x0 + 1, y, z0 + 1, x1, y + 4, z1);
    }

    // ------------------------------------------------------------ köprü (yukarı = mal köprü)
    public static void buildBridge(ServerLevel l, BlockPos start, Direction dir, boolean up) {
        Direction side = dir.getClockWise();
        BlockState plank = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        int len = 20;
        int maxY = l.getMaxBuildHeight() - 6;
        for (int i = 1; i <= len; i++) {
            int dy = up ? i : 0;
            if (start.getY() - 1 + dy > maxY) break;
            BlockPos center = start.relative(dir, i).above(dy - 1);
            for (int s = -1; s <= 1; s++) {
                BlockPos p = center.relative(side, s);
                l.setBlock(p, plank, 3);
                for (int h = 1; h <= 3; h++) l.setBlock(p.above(h), AIR, 3);
                if (s != 0) l.setBlock(p.above(1), fence, 3);
            }
        }
    }

    // ------------------------------------------------------------ malikane (17x13, 2 kat)
    public static AABB buildMansion(ServerLevel l, BlockPos c, Direction dir) {
        int y = c.getY();
        int hx = 8, hz = 6;
        int x0 = c.getX() - hx, x1 = c.getX() + hx, z0 = c.getZ() - hz, z1 = c.getZ() + hz;
        clear(l, x0 - 1, y, z0 - 1, x1 + 1, y + 12, z1 + 1);
        foundation(l, x0, x1, z0, z1, y);

        // kapı koordinatları (arka duvarın ortası, 3 geniş)
        int backX = c.getX() - dir.getStepX() * hx;
        int backZ = c.getZ() - dir.getStepZ() * hz;
        boolean xAxis = dir.getStepX() != 0;

        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();

        int ladderX = x0 + 1;
        int ladderZ = z0 + 2;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);

                set(l, x, y - 1, z, edge ? DIRT : planks); // zemin
                for (int h = 0; h <= 8; h++) {
                    int yy = y + h;
                    if (h == 4) { // 2. kat zemini
                        if (edge) set(l, x, yy, z, DIRT);
                        else if (x == ladderX && z == ladderZ) set(l, x, yy, z, AIR);
                        else set(l, x, yy, z, planks);
                    } else if (edge) {
                        boolean door = xAxis
                                ? (x == backX && Math.abs(z - c.getZ()) <= 1 && h <= 2)
                                : (z == backZ && Math.abs(x - c.getX()) <= 1 && h <= 2);
                        if (door) {
                            set(l, x, yy, z, AIR);
                        } else if (corner) {
                            set(l, x, yy, z, log);
                        } else if ((h == 1 || h == 2 || h == 5 || h == 6) && ((x + z) % 3 == 0)) {
                            set(l, x, yy, z, glass);
                        } else {
                            set(l, x, yy, z, ((x + z + h) % 5 == 0) ? COARSE : DIRT);
                        }
                    } else {
                        if (!(h == 4)) set(l, x, yy, z, AIR);
                    }
                }
                set(l, x, y + 9, z, DIRT);                       // çatı
                if (edge) set(l, x, y + 10, z, COARSE);          // siperlik
            }
        }

        // merdiven (2. kata)
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.EAST);
        for (int h = 0; h <= 4; h++) set(l, ladderX, y + h, ladderZ, ladder);

        // meşaleler (alt ve üst kat)
        set(l, x1 - 1, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y, z0 + 1, Blocks.TORCH.defaultBlockState());
        set(l, x0 + 2, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y + 5, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y + 5, z0 + 1, Blocks.TORCH.defaultBlockState());
        set(l, x0 + 2, y + 5, z1 - 1, Blocks.TORCH.defaultBlockState());

        return new AABB(x0 + 1, y, z0 + 1, x1, y + 4, z1);
    }

    // ------------------------------------------------------------ KUVARS, CAMLI, 2 KATLI GÜZEL EV (köpek kulübesi)
    /** Kahverengi yok: kuvars bloktan, camlı, içi döşeli, 2 katlı ev. Kapı oyuncuya (dir'in tersine) bakar. */
    public static AABB buildQuartzHouse(ServerLevel l, BlockPos c, Direction dir) {
        int y = c.getY();
        int h = 5; // yarım boyut: 11x11
        int x0 = c.getX() - h, x1 = c.getX() + h, z0 = c.getZ() - h, z1 = c.getZ() + h;
        clear(l, x0 - 1, y, z0 - 1, x1 + 1, y + 10, z1 + 1);

        BlockState quartz = Blocks.QUARTZ_BLOCK.defaultBlockState();
        BlockState smooth = Blocks.SMOOTH_QUARTZ.defaultBlockState();
        BlockState pillar = Blocks.QUARTZ_PILLAR.defaultBlockState();
        BlockState glass = Blocks.GLASS.defaultBlockState();
        BlockState slab = Blocks.QUARTZ_SLAB.defaultBlockState();

        // temel: kuvars
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++)
                for (int yy = y - 1; yy >= y - 4; yy--) {
                    BlockPos q = new BlockPos(x, yy, z);
                    if (yy == y - 1 || l.isEmptyBlock(q) || l.getBlockState(q).canBeReplaced()) set(l, x, yy, z, smooth);
                    else break;
                }

        // kapı: oyuncuya bakan duvarın ortası (3 geniş, 3 yüksek)
        boolean xAxis = dir.getStepX() != 0;
        int doorX = c.getX() - dir.getStepX() * h;
        int doorZ = c.getZ() - dir.getStepZ() * h;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                for (int k = 0; k <= 8; k++) {
                    int yy = y + k;
                    if (k == 3) { // 2. kat zemini
                        set(l, x, yy, z, edge ? quartz : smooth);
                    } else if (k == 7) { // çatı
                        set(l, x, yy, z, smooth);
                    } else if (k == 8) { // çatı kenar süsü
                        if (edge) set(l, x, yy, z, slab);
                    } else if (edge) {
                        boolean door = k <= 2 && (xAxis
                                ? (x == doorX && Math.abs(z - c.getZ()) <= 1)
                                : (z == doorZ && Math.abs(x - c.getX()) <= 1));
                        if (door) set(l, x, yy, z, AIR);
                        else if (corner) set(l, x, yy, z, pillar);
                        else if ((k == 1 || k == 2 || k == 5 || k == 6) && ((x + z) % 2 == 0)) set(l, x, yy, z, glass);
                        else set(l, x, yy, z, quartz);
                    }
                }
            }
        }

        // merdiven (içeride, batı duvarı boyunca): 4 basamak, kat zemininde delik bırakılır
        BlockState stair = Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH);
        int sx = x0 + 1;
        for (int i = 0; i < 4; i++) {
            int sz = z0 + 1 + i;
            set(l, sx, y + i, sz, stair);
            if (i < 3) set(l, sx, y + 3, sz, AIR); // kat deliği (basamakların üstü)
        }
        // merdiven korkuluğu
        set(l, sx + 1, y + 4, z0 + 1, Blocks.QUARTZ_SLAB.defaultBlockState());

        // ---- döşeme: alt kat
        BlockState carpet = Blocks.PINK_CARPET.defaultBlockState();
        BlockState whiteCarpet = Blocks.WHITE_CARPET.defaultBlockState();
        for (int x = x0 + 2; x <= x1 - 2; x++)
            for (int z = z0 + 2; z <= z1 - 2; z++)
                set(l, x, y, z, (x == x0 + 2 || x == x1 - 2 || z == z0 + 2 || z == z1 - 2) ? whiteCarpet : carpet);
        // kanepe + sehpa
        set(l, c.getX() - 2, y, c.getZ() + 3, Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH));
        set(l, c.getX() - 1, y, c.getZ() + 3, Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH));
        set(l, c.getX(), y, c.getZ() + 3, Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH));
        set(l, c.getX() - 1, y, c.getZ() + 1, slab);
        set(l, c.getX() - 1, y + 1, c.getZ() + 1, Blocks.POTTED_PINK_TULIP.defaultBlockState());
        // köşelerde çiçek saksıları
        set(l, x1 - 1, y, z1 - 1, Blocks.POTTED_PINK_TULIP.defaultBlockState());
        set(l, x1 - 1, y, z0 + 1, Blocks.POTTED_AZALEA_BUSH.defaultBlockState());
        // sarkan fenerler
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        set(l, c.getX(), y + 2, c.getZ(), lantern);
        set(l, c.getX() - 3, y + 2, c.getZ(), lantern);
        set(l, c.getX() + 3, y + 2, c.getZ(), lantern);

        // ---- döşeme: üst kat (pembe yatak, halı, fenerler)
        for (int x = x0 + 2; x <= x1 - 2; x++)
            for (int z = z0 + 2; z <= z1 - 2; z++)
                set(l, x, y + 4, z, whiteCarpet);
        BlockPos foot = new BlockPos(c.getX() + 2, y + 4, c.getZ() + 3);
        l.setBlock(foot, Blocks.PINK_BED.defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH).setValue(BedBlock.PART, BedPart.FOOT), 3);
        l.setBlock(foot.north(), Blocks.PINK_BED.defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH).setValue(BedBlock.PART, BedPart.HEAD), 3);
        set(l, c.getX(), y + 4, c.getZ() + 3, Blocks.POTTED_PINK_TULIP.defaultBlockState());
        set(l, c.getX(), y + 6, c.getZ(), lantern);
        set(l, c.getX() + 3, y + 6, c.getZ() - 2, lantern);
        set(l, c.getX() - 3, y + 6, c.getZ() + 2, lantern);

        return new AABB(x0, y, z0, x1 + 1, y + 7, z1 + 1);
    }

    // ------------------------------------------------------------ MUTFAK TEZGAHI (Dumbity)
    public record Kitchen(BlockPos focus, BlockPos standDumbity, BlockPos standMality) {}

    private static BlockPos at(BlockPos base, Direction dir, Direction side, int ls, int ld, int up) {
        return base.relative(side, ls).relative(dir, ld).above(up);
    }

    /** Geniş, dikdörtgen, kuvarstan güzel bir tezgah. base: tezgahın önündeki zemin hizası (ld=0). */
    public static Kitchen buildKitchen(ServerLevel l, BlockPos base, Direction dir) {
        Direction side = dir.getClockWise();
        BlockState quartz = Blocks.QUARTZ_BLOCK.defaultBlockState();
        BlockState smooth = Blocks.SMOOTH_QUARTZ.defaultBlockState();
        BlockState slab = Blocks.QUARTZ_SLAB.defaultBlockState();
        BlockState glass = Blocks.GLASS.defaultBlockState();

        // alan temizle
        for (int ls = -5; ls <= 5; ls++)
            for (int ld = -2; ld <= 3; ld++)
                for (int up = 0; up <= 4; up++) l.setBlock(at(base, dir, side, ls, ld, up), AIR, 3);
        // zemin: beyaz / açık gri karo + altı dolgu
        for (int ls = -5; ls <= 5; ls++)
            for (int ld = -2; ld <= 3; ld++) {
                BlockState floor = ((ls + ld) & 1) == 0 ? Blocks.WHITE_CONCRETE.defaultBlockState()
                        : Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
                l.setBlock(at(base, dir, side, ls, ld, -1), floor, 3);
                for (int dn = 2; dn <= 4; dn++) {
                    BlockPos q = at(base, dir, side, ls, ld, -dn);
                    if (l.isEmptyBlock(q) || l.getBlockState(q).canBeReplaced()) l.setBlock(q, smooth, 3);
                    else break;
                }
            }
        // tezgah gövdesi: 9 uzun, 2 derin
        for (int ls = -4; ls <= 4; ls++) {
            l.setBlock(at(base, dir, side, ls, 1, 0), quartz, 3);
            l.setBlock(at(base, dir, side, ls, 2, 0), quartz, 3);
            l.setBlock(at(base, dir, side, ls, 1, 1), slab.setValue(net.minecraft.world.level.block.SlabBlock.TYPE,
                    net.minecraft.world.level.block.state.properties.SlabType.TOP), 3);
        }
        // arka sıra: aletler ve süsler
        BlockState furnace = Blocks.FURNACE.defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, dir.getOpposite());
        BlockState blast = Blocks.BLAST_FURNACE.defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, dir.getOpposite());
        l.setBlock(at(base, dir, side, -4, 2, 1), Blocks.CAULDRON.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, -3, 2, 1), Blocks.POTTED_PINK_TULIP.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, -2, 2, 1), Blocks.BREWING_STAND.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, -1, 2, 1), Blocks.PINK_CANDLE.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, 0, 2, 1), furnace, 3);
        l.setBlock(at(base, dir, side, 1, 2, 1), Blocks.PINK_CANDLE.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, 2, 2, 1), blast, 3);
        l.setBlock(at(base, dir, side, 3, 2, 1), Blocks.POTTED_PINK_TULIP.defaultBlockState(), 3);
        l.setBlock(at(base, dir, side, 4, 2, 1), Blocks.CAULDRON.defaultBlockState(), 3);
        // arka cam duvar + köşe sütunları + fenerler
        for (int ls = -5; ls <= 5; ls++) {
            boolean post = ls == -5 || ls == 5;
            for (int up = 0; up <= 2; up++) {
                BlockState st = post ? Blocks.QUARTZ_PILLAR.defaultBlockState() : (up == 1 ? glass : quartz);
                l.setBlock(at(base, dir, side, ls, 3, up), st, 3);
            }
        }
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, false);
        l.setBlock(at(base, dir, side, -5, 3, 3), lantern, 3);
        l.setBlock(at(base, dir, side, 5, 3, 3), lantern, 3);

        BlockPos focus = at(base, dir, side, 0, 1, 1);
        return new Kitchen(focus, at(base, dir, side, -1, 0, 0), at(base, dir, side, 1, 0, 0));
    }
}
