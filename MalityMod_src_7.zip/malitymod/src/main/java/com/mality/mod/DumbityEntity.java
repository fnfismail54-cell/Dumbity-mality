package com.mality.mod;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Dumbity: Mality'nin sevgilisi. Daha akıllı ve nazik; Mality ile konuşur. */
public class DumbityEntity extends MalityEntity {
    private static final String[] LINES = {
            "Bugün hava çok güzel, Mality de yanımda, ne mutlu.", "Biraz dinlenelim mi? Yoruldun mu?",
            "Kahverengi pek sevmem, pembe ve beyaz çok daha güzel.", "Çiçekleri çok seviyorum, sen de sever misin?",
            "Sana yardım etmek isterim, bir şey lazım mı?", "Mality'nin yanında hiç sıkılmıyorum.",
            "Bugün yeni bir şey öğrendim, birlikte düşünelim mi?", "Etrafta tehlike var mı diye baktım, sakin görünüyor."
    };

    public DumbityEntity(EntityType<? extends MalityEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected String displayName() {
        return "Dumbity";
    }

    @Override
    protected String chatColor() {
        return "\u00A7b";
    }

    @Override
    protected String persona() {
        return GroqClient.DUMBITY_SYSTEM;
    }

    @Override
    protected String voiceModel() {
        String v = Config.FISH_MODEL_DUMBITY.get();
        return v == null || v.isBlank() ? Config.FISH_MODEL.get() : v;
    }

    @Override
    protected String[] dumbLines() {
        return LINES;
    }

    @Override
    protected boolean isSmart() {
        return true;
    }

    private static final String[] ADD = {
            "Şimdi %s ekliyorum.", "Tarife göre biraz %s lazım.", "Sırada %s var, dikkatlice ekleyelim.", "Biraz da %s koyalım mı?"
    };
    private static final String[] PRAISE_L = {
            "Tadına baktım, bence çok güzel oldu.", "Hazır! Umarım beğenirsin.", "Tam kıvamında, kokusu harika."
    };

    @Override
    protected String[] addLines() {
        return ADD;
    }

    @Override
    protected String[] praiseLines() {
        return PRAISE_L;
    }
}
