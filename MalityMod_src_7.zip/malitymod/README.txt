MALITY MOD  -  Minecraft Java 1.20.1  -  Forge 47.x  -  Java 17
==============================================================

KURULUM / DERLEME (en kolay yol)
1) https://files.minecraftforge.net adresinden 1.20.1 icin "MDK" indir (47.3.0 veya yakini) ve ac.
2) Bu zip'teki "src" klasorunu MDK'nin icindeki "src" klasorunun ustune kopyala (mevcut Example mod
   dosyalarini sil: src/main/java/com/example..., eski mods.toml).
3) MDK'deki build.gradle ve gradle.properties icindeki mod id'yi "malitymod", paket/group'u
   "com.mality.mod" yap. (Alternatif: bu zip'teki build.gradle'i ve settings.gradle'i kullan,
   gradle wrapper'i MDK'den kopyala: gradlew, gradlew.bat, gradle/ klasoru.)
4) JDK 17 kurulu olsun. Terminalde:   gradlew build
5) Jar:  build/libs/malitymod-1.0.0.jar  ->  .minecraft/mods klasorune at.
   (Forge 1.20.1 kurulu olmali.)

OYUN ICI (v2)
- Yaratici envanteri > "Mality" sekmesi: Malitynin Mavi Kutusu, Mality Canlandirma Yumurtasi,
  Malitynin Super Keki.
- Mavi kutuyu yere koy, SAG TIK: havaya kalkar, ses cikar, Mality duser ("tip"), sacma seyler soyler.
- Ayarlar: Mods > Mality > Config: Groq API key + model, Fish Audio API key + Fish Audio ses model ID
  (Fish Audio sitesindeki voice model ID), "mality de" kutusu.
  Fish Audio key bos ise Mality sessiz konusur (sadece yazi). Anahtarlar config/malitymod-common.toml
  icinde duz yazi saklanir, paylasma!
- Komutlar: "yemek yap" (asci sapkasi, tezgah, malzemeler, super kek), "yemek ye", "toprak ver",
  "yardim et", "ev yap" (kotu ev; "kotu ev yap" derseniz guzel yapar), "kopek kulubesi yap" (malikane),
  "kopru yap" (yukari; "kotu kopru" duz yapar), "uyu", "takip et", "dur/bekle".
- Sohbete /setmalityyatak yaz: en yakin Mality'nin yatagi bulundugun yer olur. "uyu" deyince ya da
  gece olunca yuvarlanarak oraya gider ve uyur.
- Super kek: bulanti + rastgele ucak / tavsan (yuksek ziplama) / osuruk. Zehirliyse kisa zehir (olmez).

YUZLER (HER YUZ AYRI DOSYA)
assets/malitymod/textures/entity/ icinde 7 ayri dosya (her biri kare, ornegin 64x64 ya da 128x128):
  mality_happy.png        normal mutlu
  mality_happy_talk.png   mutlu konusurken
  mality_bored.png        sikilmis / korkunc
  mality_bored_talk.png   sikilmis konusurken
  mality_sleep.png        uyuyan
  mality_scared.png       korkmus
  mality_fall.png         kutudan duserken
Her resmin ortasina YUVARLAK yuz ciz. Resmin kenarlari / sol ust kosesi top rengi olsun
(topun arka yarisi o kosenin rengini alir). Dosya adlarini degistirme, ustune yaz.

SESLI KONUSMA (v3)
- M tusuna basili tut ve konus. Sessizlik olunca (ya da tusu birakinca) konusman Groq Whisper ile yaziya
  cevrilip sohbette GORUNMEDEN dogrudan Mality'ye gider, Mality cevap verir. Tus: Kontroller > "Mality" kategorisi.
- Android'de Zalith'e mikrofon izni ver (Ayarlar > Uygulamalar > Zalith > Izinler > Mikrofon).

DUMBITY (Mality'nin sevgilisi)
- Pembe kutu (Yaratici envanteri > Mality sekmesi) ya da oyuna ilk giriste yaninda dogan iki kutu: mavi = Mality, pembe = Dumbity.
  /malitykutu yazarsan iki kutu yine yaninda dogar. Kutuya sag tik.
- Konusma: M basili tut = Mality, N basili tut = Dumbity (Kontroller > Mality). Sohbete "dumbity ..." yazarsan da Dumbity duyar.
- Dumbity "yemek yap" duyunca genis kuvars tezgah kurar, Mality'yi de cagirir: o iyi (bazen yanlislikla kotu), Mality kotu yemek yapar.
- Mality'ye "kopek kulubesi yap": kuvarstan, camli, ici dosenmis 2 katli ev.
- Dumbity ses modeli: /dumbityses <fish ses id>

SORUN GIDERME
- Oyunda sohbete /malitytest yaz: Groq, Fish Audio ve ses calma ayri ayri denenir, sonuc sohbette cikar.
- Mality'nin Groq/ses hatalari sohbette kirmizi "[Mality hata]" olarak gorunur.

BILGISAYARSIZ DERLEME (GitHub ile)
Depoya (repo) tum dosyalari, .github/workflows/build.yml dahil, yukle. Actions sekmesi >
"Build Mality Mod" > Run workflow. Bitince "malitymod-jar" artifact'ini indir, icinden jar cikar.
